<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Jenisbayar extends Model
{
    protected $table = 'jenisbayar';
    protected $guarded = [];
}
