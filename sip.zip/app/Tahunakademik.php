<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Tahunakademik extends Model
{
    protected $table = 'tahunakademik';
    protected $guarded = [];
}
