<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Rincianbiaya extends Model
{
    protected $table = 'rincian_biaya_siswa';
    protected $guarded = [];
}
