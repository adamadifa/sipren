<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Historibayar_detail extends Model
{
    protected $table = 'historibayar_detail';
    protected $guarded = [];
}
