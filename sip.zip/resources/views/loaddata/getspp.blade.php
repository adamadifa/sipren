<?php 
$spp = $databiaya->jumlah_biaya;
$mulaispp = $databiaya->mulai_pembayaran;
$totalspp = 0;
for($i=1; $i<=12; $i++){
  $totalspp += $spp;
  if($mulaispp>12){
    $mulaispp =1;
  }

  $bayar = DB::table('historibayar_detail')
            ->join('historibayar', 'historibayar_detail.no_transaksi', '=', 'historibayar.no_transaksi')
            ->where('no_pendaftaran', $no_pendaftaran)
            ->where('kodebiaya',$databiaya->kodebiaya)
            ->where('id_jenisbayar','11')
            ->where('ket',$mulaispp)
            ->first();


  
  ?>
<tr>
  <td>{{$namabulan[$mulaispp]}}</td>
  <td align="right" style="font-weight: 700">{{number_format($spp,'0','','.')}}</td>
  <td align="right" style="color: green; font-weight:bold">
    @if (!empty($bayar->jumlah_bayar))
    @php
    $bayar = $bayar->jumlah_bayar;
    @endphp
    @else
    @php
    $bayar = 0;
    @endphp
    @endif
    {{number_format($bayar,'0','','.')}}
  </td>
  <td align="right" style="color: red; font-weight:bold">
    @php
    $sisa = $spp - $bayar;
    @endphp
    {{number_format($sisa,'0','','.')}}
  </td>
</tr>
<?php
$mulaispp++;
}
?>
<tr class="thead-dark">
  <th>TOTAL</th>
  <th style="text-align: right">{{number_format($totalspp,'0','','.')}}</th>
  <th></th>
  <th></th>
</tr>