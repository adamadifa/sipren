<iframe src="{{url('absensi/map?nama='.$nama.'&latitude='.$latitude.'&longitude='.$longitude)}}" frameborder="0"
    width="100%" height="400px" marginwidth="0" marginheight="0" scrolling="no">
