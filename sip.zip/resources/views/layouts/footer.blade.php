<div class="modal modal-blur fade" id="loading" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog modal-sm modal-dialog-centered" role="document">
    <img id="loading-image" width="100" height="100" src="{{asset('assets/static/loading/loading1.gif')}}" />
  </div>
</div>