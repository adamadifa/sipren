<div class="page-pretitle">
  @yield('page-pretitle')
</div>
<h2 class="page-title">
  @yield('page-title')
</h2>
<div class="row">
  @yield('content')
</div>
</div>