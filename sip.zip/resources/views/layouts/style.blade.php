<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link href="{{asset('assets/dist/css/bootstrap.css')}}" rel="stylesheet" />
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.25/css/dataTables.bootstrap4.min.css">
<link href="{{asset('assets/dist/libs/flatpickr/dist/flatpickr.min.css')}}" rel="stylesheet" />
<link href="{{asset('assets/dist/libs/jqvmap/dist/jqvmap.min.css')}}" rel="stylesheet" />
<link href="{{asset('assets/dist/css/tabler.min.css')}}" rel="stylesheet" />
<link href="{{asset('assets/dist/css/tabler-flags.min.css')}}" rel="stylesheet" />
<link href="{{asset('assets/dist/css/tabler-payments.min.css')}}" rel="stylesheet" />
<link href="{{asset('assets/dist/css/tabler-vendors.min.css')}}" rel="stylesheet" />
<link href="{{asset('assets/dist/css/demo.min.css')}}" rel="stylesheet" />





<style>
    body {
        display: none;
    }

    .grid-container {
        display: grid;
        grid-template-columns: 65px 1fr;
        /* background-color: aqua; */
    }

    .grid-item {
        /* background-color: rgba(255, 255, 255, 0.8); */
        /* border: 1px solid rgba(0, 0, 0, 0.8); */
        /* padding: 20px;
    font-size: 30px;
    text-align: center; */
    }

    .grid-container2 {
        display: grid;
        grid-template-columns: 100px 1fr;
        /* background-color: aqua; */
    }



    #chartdiv {
        width: 100%;
        height: 200px;
    }

    .warnaputih {
        color: white;
    }
</style>
